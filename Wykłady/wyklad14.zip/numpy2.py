#!/usr/bin/env python
# coding: utf-8

# # Wprowadzenie do numpy

# Do czego służy:

# - obliczenia numeryczne (mnożenie i dodawanie macierzy, diagonalizacja czy odwrócenie, rozwiązywanie równań)
# - tworzenie specjalizowanych typów danych, operacji i funkcji, których nie ma w typowej instalacji Pythona

# In[1]:


import numpy as np


# In[2]:


# jak dotychczas reprezentowaliśmy macierze (tablice 2x2):
X = [[1, 2, 3], [4, 5, 6]]
print(X)
print(type(X))


# In[3]:


# ndarray - klasa, najważniejszy obiekt: tablica obiektów (zazwyczaj liczb)
X = np.array([[1, 2, 3], [4, 5, 6]])
print(X)
print(type(X))
print(X)
X[0][0] = 50
print(X)
X[0,0] = 100 # jak X[0][0]
print(X)


# ## Slicing

# In[4]:


# Przypomnienie: dla list i stringów slicing tworzy kopię obiektu
a = [1,2,3,4,5]
b = a[:]

a[2] = -1
print(a)
print(b)


# In[5]:


X = np.array([[1, 2, 3, 4], [4, 5, 6, 7], [2, 2, 1, 1]])
print(X)


# In[6]:


Y = X[:, :] # wszystkie wiersze i kolumny
print(Y)


# In[7]:


Y = X[:2, :] # wiersze < 2, wszystkie kolumny
print(Y)


# In[8]:


Y = X[1:3, :] # wiersze 1, 2
print(Y) 


# In[9]:


Y = X[:2, 2:] # wiersze 0, 1, kolumny 2 i dalej
print(Y)


# In[10]:


Y[0,0] = 1000
print(Y)
print(X) # zmieniła się!


# In[11]:


Y = X[1, :]
print(Y)

Y = X[1:2, :]
print(Y)


# ## Proste charakterystyki danych

# In[12]:


X = np.array([[1, 2, 3], [4, 5, 6]])
print(X)


# In[13]:


print(np.sum(X)) # suma wszystkich elementów tablicy
print(np.sum(X, axis=0)) # sumowanie po kolumnach
print(np.sum(X, axis=1)) # sumowanie po wierszach


# In[14]:


print(np.cumsum(X))
print(np.cumsum(X, axis=0))
print(np.cumsum(X, axis=1))


# In[15]:


print(np.mean(X))
print(np.mean(X, axis=0))
print(np.mean(X, axis=1))


# In[16]:


print(np.std(X))
print(np.std(X, axis=0))
print(np.std(X, axis=1))


# In[17]:


print(np.max(X))
print(np.max(X, axis=0))
print(np.max(X, axis=1))


# In[18]:


print(np.min(X))
print(np.min(X, axis=0))
print(np.min(X, axis=1))


# ## Tworzenie tablic

# In[19]:


X = np.zeros((2,2)) # macierz zerowa rozmiaru 2x2.
print(X)


# In[20]:


X = np.ones((2,2)) # macierz z samymi jedynkami rozmiaru 2x2.
print(X)


# In[21]:


X = np.full((3,3), 2021) # macierz rozmiaru 3x3 z każdą pozycją równą 2021.
print(X)


# In[22]:


X = np.eye(5) # macierz identycznościowa rozmiaru 5x5.
print(X)


# In[23]:


X = np.arange(-np.pi, np.pi, 0.1) # punkty [-pi, pi+0.1, pi+0.2, ...] z przedziału [-pi, pi).
print(X)


# In[24]:


X = np.linspace(0,1,13) # 13 punktów równoodległych w przedziale [0,1].
print(X)


# In[25]:


print(np.repeat(3, 4)) # powtórz 4 razy wartość 3
print(np.repeat(np.array([1,2,3]), 2)) 
print(np.tile(np.array([1,2,3]), 2)) # porównaj z poprzednim.


# # Operacje macierzowe

# ## Transpozycja

# In[26]:


A = np.array([1, 2]) # wektor 1D
B = np.array([[3], [4]]) # macierz 2D rozmiaru 2x1
print(A)
print(A.shape)


# In[27]:


print(B)
print(B.shape)


# In[28]:


print(A.T) # transpozycja wektora 1D - ten sam wektor!
print(A.T.shape)


# In[29]:


print(B.T)
print(B.T.shape)


# In[30]:


print(A[np.newaxis]) # wektor 1D rozszerzony do macierzy 2D rozmiaru 1x2
print(A[np.newaxis].shape)


# In[31]:


print(A[np.newaxis].T)
print(A[np.newaxis].T.shape)


# ## Wybór indeksów, zmiana kształtu

# In[32]:


X = np.array(range(10,20))
print(X)
Y = X % 2
print(Y)
Z = Y == 1
print(Z)
print(X[Z]) 
print(np.where(Z)) # pozycje na których wartość jest równa True


# In[33]:


X = np.array(range(10,20))
print(X > 14)
print(X <= 18)
print((X > 14) & (X <= 18))
print(X[(X > 14) & (X <= 18)]) # dwa warunki, & zamiast and!


# In[34]:


X = np.arange(1,10)
print(X)

Y = X.reshape(3, 3)  # też widok!
print(Y)
print(X)


# ## Mnożenie macierzy

# In[35]:


# Przypomnienie: jak działa mnożenie dla list i napisów.
print("123"*10)
a = [1,2,3]
print(a * 3)

print("*"*30)
print([x*3 for x in a])

# print(a+5) # błąd!


# In[36]:


Y = np.arange(1,10).reshape((3,3))

print(Y)
print(Y * 3) # produkt Hadamarda
print(Y + 77)
print(Y * Y)
print(Y @ Y) # mnożenie macierzowe (__matmul__)


# In[37]:


Z = np.repeat(2, 3)
print(Z)
print(Z * Y) # broadcasting + mnożenie po współrzędnych
print(Y @ Z) # mnożenie macierzowe
print(Z @ Y) # mnożenie macierzowe, Z interpretowany jako macierz 1x3


# <img src="broadcasting.png"/>

# In[38]:


X = np.array([1, 2, 3])
Y = np.array([2, 3, 4])
print(X)
print(Y)

print("-----------------------")
print(np.vstack((X,Y)))

print("-----------------------")
print(np.hstack((X,Y)))


# ## Wyznacznik i odwracanie macierzy

# In[39]:


A = np.array([[0, 3, 2], [1, 0, 4], [0, 3, 6]])
print(A)
print(np.linalg.det(A))
B = np.linalg.inv(A)
print(B)
Y = np.array([3, -1, 2])
print(B @ Y)


# # Unique

# In[40]:


unique = np.unique([1, 1, 2, 2, 2, 3, 3, 67, -1])
print(unique)

unique, counts = np.unique([1, 1, 2, 2, 2, 3, 3, 67, -1], return_counts=True)
print(unique, counts)


# # Opcje wyświetlania

# In[41]:


X = np.arange(-np.pi, np.pi, 0.02)
print(X)

np.set_printoptions(suppress=True) # pozbycie sie notacji naukowej
print(X)

np.set_printoptions(precision=5) # wyswietlanie tylko 5 miejsc po przecinku
print(X)


# # Wczytywanie i zapisywanie do pliku

# In[42]:


wines = np.genfromtxt("wine.txt", delimiter=',', skip_header=1)


# In[43]:


print(wines)
print(wines.dtype)


# In[44]:


mushrooms = np.genfromtxt("mushrooms.txt", delimiter=',', skip_header=1, dtype=str)


# In[45]:


print(mushrooms)
print(mushrooms.dtype)


# In[46]:


X = np.linspace(0,1,13)
print(X)

print('-------------------')
np.savetxt('test.txt', X)
print(np.loadtxt('test.txt'))


# # Generatory liczb losowych

# In[47]:


from matplotlib import pyplot as plt


# In[48]:


# od 3.6 też w standardowym random:
X = np.random.choice([1,2,3,4,5,6], 1000, p=[0.1, 0.2, 0.3, 0.2, 0.1, 0.1]) # losowanie 1000 liczb z rozkładu opisanego przez p
print(X)


# In[49]:


plt.hist(X, bins=6)
plt.show()


# In[50]:


X = np.random.normal(1, 3, 10000) # rozkład normalny o średniej 1 i odchyleniu standardowym 3
plt.hist(X, bins=200)
plt.show()


# In[51]:


X = np.random.uniform(2, 4, 10000) # rozkład jednostajny na odcinku [2, 4).
plt.hist(X, bins=20)
plt.show()


# # Wektoryzacja

# In[52]:


X = np.linspace(-2*np.pi, 2*np.pi, 1000)
print(np.sin(X))
print(np.exp(X))


# In[53]:


import math


# In[54]:


# print(math.sin(X)) # błąd!
# print(math.exp(X)) # błąd!


# In[55]:


def f(x):
    if x < 0:
        return 78
    elif x % 2 == 1:
        return -1
    else:
        return 20


# In[56]:


X = np.arange(-10, 11)
print(X)


# In[57]:


# f(X) # błąd!


# In[58]:


# I sposób
f1 = np.vectorize(f)
print(f1(X))


# In[59]:


# II sposób (oznacza dokładnie to samo)

@np.vectorize
def f1(x):
    if x < 0:
        return 78
    elif x % 2 == 1:
        return -1
    else:
        return 20


# In[60]:


print(f1(X))


# # numpy a matplotlib

# In[61]:


X = np.linspace(-2*np.pi, 2*np.pi, 1000)
plt.plot(X, np.sin(X))
plt.show()


# In[62]:


t = np.arange(0, 2.5, 0.1)
y1 = np.sin(np.pi*t)
y2 = np.sin(np.pi*t + np.pi/2)
y3 = np.sin(np.pi*t - np.pi/2)


# In[63]:


plt.plot(t, y1, 'b--', t, y2, 'g', t, y3, 'r-')
plt.show()


# In[64]:


plt.plot(t, np.sin(t**2))
plt.xlabel('t')
plt.ylabel('$\sin(t^2)$') # wyrażenie LaTeXa na osi OY.
plt.show()

